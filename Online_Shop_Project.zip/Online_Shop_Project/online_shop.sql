-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: May 25, 2023 at 01:30 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE `administrators` (
  `F_name` varchar(50) NOT NULL,
  `L_name` varchar(50) NOT NULL,
  `Admin_email` varchar(50) NOT NULL,
  `Admin_birth_date` date NOT NULL,
  `Admin_age` int(11) DEFAULT NULL,
  `Admin_sex` varchar(6) NOT NULL,
  `Admin_phone` int(15) NOT NULL,
  `Admin_address` varchar(100) NOT NULL,
  `Admin_nationality` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`F_name`, `L_name`, `Admin_email`, `Admin_birth_date`, `Admin_age`, `Admin_sex`, `Admin_phone`, `Admin_address`, `Admin_nationality`) VALUES
('Alice', 'Smith', 'alicesmith@example.com', '1985-02-28', 36, 'Female', 2147483647, 'Tripoli', 'Lebanese'),
('John', 'Doe', 'johndoe@example.com', '1990-01-01', 31, 'Male', 2147483647, 'Beirut', 'Lebanese'),
('Mohamed', 'Ali', 'mohamedali@example.com', '1978-11-30', 43, 'Male', 2147483647, 'Beirut', 'Lebanese'),
('Patrick', 'Jane', 'pj@gmail.com', '2004-06-07', 18, 'male', 70896542, 'Beirut', 'Lebanese'),
('Samuel', 'Johnson', 'samueljohnson@example.com', '1983-05-12', 38, 'Male', 2147483647, 'Byblos', 'British'),
('Sara', 'Lee', 'saralee@example.com', '1995-09-21', 26, 'Female', 2147483647, 'Sidon', 'Lebanese');

-- --------------------------------------------------------

--
-- Table structure for table `advertisers`
--

CREATE TABLE `advertisers` (
  `Emp_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advertisers`
--

INSERT INTO `advertisers` (`Emp_ID`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `Comp_name` varchar(100) NOT NULL,
  `Comp_address` varchar(100) DEFAULT NULL,
  `Comp_nationality` varchar(50) DEFAULT NULL,
  `Comp_email` varchar(50) NOT NULL,
  `Comp_Phone` int(15) NOT NULL,
  `type_of_products` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`Comp_name`, `Comp_address`, `Comp_nationality`, `Comp_email`, `Comp_Phone`, `type_of_products`) VALUES
('ABC Company', '123 Main St', 'USA', 'abc@example.com', 1234567890, 'Makeup'),
('Bookworms Inc.', '456 1st Ave, Seattle, WA', 'USA', 'bwinc@gmail.com', 2147483647, 'Books'),
('Clean Living Co.', '654 4th St, Miami, FL', 'USA', 'cleanliving@gmail.com', 2147483647, 'Clean_Products'),
('Clorox', 'Oakland', 'American', 'clorox@gmail.com', 67543256, 'Clean_Products'),
('DEF Company', '456 Elm St', 'Canada', 'def@example.com', 2147483647, 'Books'),
('Electronics Emporium', '789 2nd St, San Francisco, CA', 'USA', 'electroemp@gmail.com', 2147483647, 'Phones'),
('Fashion Forward', '987 5th Ave, Los Angeles, CA', 'USA', 'fashionforward@gmail.com', 2147483647, 'Clothes'),
('Fit & Fabulous', '369 8th St, Chicago, IL', 'USA', 'fitfab@gmail.com', 2147483647, 'Fitness_Products'),
('GHI Company', '789 Oak St', 'UK', 'ghi@example.com', 2147483647, 'Phones'),
('Glamorous Cosmetics', '123 Main St, New York, NY', 'USA', 'glamcos@gmail.com', 1234567890, 'Makeup'),
('Home Sweet Home', '258 7th Ave, Denver, CO', 'USA', 'homesweethome@gmail.com', 2147483647, 'Home_decor'),
('MNO Company', '654 Pine St', 'Germany', 'mno@example.com', 2147483647, 'Clean_Products'),
('Pet Pals Supply', '147 6th St, Austin, TX', 'USA', 'petpals@gmail.com', 2147483647, 'Pet_Supplies'),
('STU Company', '246 Walnut St', 'France', 'stu@example.com', 2147483647, 'Pet_Supplies'),
('TechTrendz LLC', '321 3rd Ave, Boston, MA', 'USA', 'techtrendz@gmail.com', 2147483647, 'Desktops');

-- --------------------------------------------------------

--
-- Table structure for table `concerning`
--

CREATE TABLE `concerning` (
  `Offer_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `concerning`
--

INSERT INTO `concerning` (`Offer_ID`, `Product_ID`) VALUES
(1, 13),
(1, 14),
(2, 1),
(2, 2),
(2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `creates`
--

CREATE TABLE `creates` (
  `Emp_ID` int(11) NOT NULL,
  `Offer_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `creates`
--

INSERT INTO `creates` (`Emp_ID`, `Offer_ID`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `F_name` varchar(50) NOT NULL,
  `L_name` varchar(50) NOT NULL,
  `Customer_sex` char(6) DEFAULT NULL,
  `Customer_nationality` varchar(50) DEFAULT NULL,
  `Customer_birth_date` date DEFAULT NULL,
  `Customer_age` int(11) DEFAULT NULL,
  `Customer_address` varchar(100) NOT NULL,
  `Customer_phone` int(15) NOT NULL,
  `Customer_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`F_name`, `L_name`, `Customer_sex`, `Customer_nationality`, `Customer_birth_date`, `Customer_age`, `Customer_address`, `Customer_phone`, `Customer_email`) VALUES
('ali', 'basbous', 'male', 'lebanese', '1957-01-01', 66, 'Sidon', 79754656, 'ab@gmail.com'),
('Alice', 'Johnson', 'Female', 'Australian', '1995-12-05', 26, 'Tyre', 2147483647, 'alice.johnson@example.com'),
('ali', 'kooslof', 'male', 'kmpo;', '1955-07-01', 67, 'Baakline', 8391, 'balnk'),
('Bob', 'Smith', 'Male', 'British', '1990-03-10', 31, 'Tripoli', 2147483647, 'bob.smith@example.com'),
('coulmen', 'elmond', 'male', 'american', '1999-08-06', 23, 'Bcharre', 67392013, 'ce@gmail.com'),
('dwdw', 'cdwsccdwc', 'male', 'dqw', '1950-01-01', 73, 'Tripoli', 21, 'cew21'),
('few', 'cwrcc', 'male', 'cdswrd', '1954-01-01', 69, 'Beirut', 3232, 'cewrcew'),
('vdsfds', 'csa', 'male', 'cew', '1955-01-01', 68, 'Beirut', 32, 'csacd'),
('David', 'Lee', 'Male', 'South Korean', '1988-07-12', 33, 'Zahle', 2147483647, 'david.lee@example.com'),
('Emily', 'Wang', 'Female', 'Chinese', '1998-01-01', 23, 'Bcharre', 2147483647, 'emily.wang@example.com'),
('Jacob', 'Kim', 'Male', 'South Korean', '1993-06-08', 28, 'Jounieh', 2147483647, 'jacob.kim@example.com'),
('Jane', 'Doe', 'Female', 'Canadian', '1985-08-20', 36, 'Byblos', 2147483647, 'jane.doe@example.com'),
('Jenny', 'Brown', 'Female', 'American', '1992-11-25', 29, 'Baakline', 2147483647, 'jenny.brown@example.com'),
('ali', 'jonono', 'male', 'nionoi', '1950-01-01', 73, 'Tripoli', 8909, 'jnoi'),
('alaa', '8oson', 'male', 'jopo', '1953-01-01', 70, 'Beirut', 898, 'jnoin'),
('John', 'Doe', 'Male', 'American', '1980-05-15', 41, 'Beirut', 2147483647, 'john.doe@example.com'),
('john', 'petersin', 'male', 'lebanese', '1954-01-01', 69, 'Beirut', 78234532, 'john.petersin@gmail.com'),
('ali', 'ba7soon', 'male', 'lebans', '1950-01-01', 73, 'Beirut', 90, 'kool'),
('mike', 'angelo', 'male', 'lebanese', '1950-01-01', 73, 'Beirut', 84920442, 'ma@gmail.com'),
('mikel', 'clowe', 'male', 'lebanese', '2004-05-24', 19, 'Sidon', 89890, 'mc@gmail.com'),
('Olivia', 'Hernandez', 'Female', 'Mexican', '1997-12-30', 24, 'Aanjar', 2147483647, 'olivia.hernandez@example.com'),
('Sami', 'jameel', 'male', 'Lebanese', '1953-06-02', 69, 'Sidon', 80976543, 'sj@gmail.com'),
('Sophia', 'Chen', 'Female', 'Taiwanese', '1986-09-17', 35, 'Jbeil', 2147483647, 'sophia.chen@example.com'),
('Tom', 'Wilson', 'Male', 'New Zealander', '1983-02-28', 38, 'Sidon', 2147483647, 'tom.wilson@example.com'),
('William', 'Garcia', 'Male', 'Mexican', '1989-04-23', 32, 'Batroun', 2147483647, 'william.garcia@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_places`
--

CREATE TABLE `delivery_places` (
  `Emp_ID` int(11) NOT NULL,
  `delivery_places` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery_places`
--

INSERT INTO `delivery_places` (`Emp_ID`, `delivery_places`) VALUES
(11, 'Beirut'),
(11, 'Byblos'),
(11, 'Tripoli'),
(12, 'Baakline'),
(12, 'Hamra'),
(12, 'Sidon'),
(12, 'Tyre'),
(13, 'kraytem'),
(13, 'Zahle'),
(14, 'Aanjar'),
(14, 'Batroun'),
(14, 'Jbeil'),
(15, 'Deir el Qamar'),
(15, 'Faraya'),
(15, 'Harissa'),
(16, 'Beirut'),
(16, 'Byblos'),
(16, 'Tripoli'),
(17, 'Baakline'),
(17, 'Sidon'),
(17, 'Tyre'),
(18, 'Zahle'),
(19, 'Aanjar'),
(19, 'Batroun'),
(20, 'Deir el Qamar'),
(20, 'Faraya'),
(20, 'Harissa'),
(21, 'Beirut'),
(21, 'Byblos'),
(22, 'Byblos'),
(22, 'Kraytem');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Emp_ID` int(11) NOT NULL,
  `F_name` varchar(50) NOT NULL,
  `L_name` varchar(50) NOT NULL,
  `Emp_sex` char(6) DEFAULT NULL,
  `Emp_nationality` varchar(50) DEFAULT NULL,
  `Emp_address` varchar(100) DEFAULT NULL,
  `Emp_email` varchar(50) NOT NULL,
  `Emp_phone` int(15) NOT NULL,
  `Emp_birth_date` date NOT NULL,
  `hiring_date` date NOT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `Emp_age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Emp_ID`, `F_name`, `L_name`, `Emp_sex`, `Emp_nationality`, `Emp_address`, `Emp_email`, `Emp_phone`, `Emp_birth_date`, `hiring_date`, `salary`, `Emp_age`) VALUES
(1, 'John', 'Doe', 'Male', 'USA', '123 Main St.', 'johndoe@company.com', 123456789, '1995-01-01', '2021-01-01', '1100.00', 26),
(2, 'Jane', 'Smith', 'Female', 'Canada', '456 Elm St.', 'janesmith@company.com', 987654321, '1990-05-05', '2018-05-05', '1100.00', 31),
(3, 'Mark', 'Johnson', 'Male', 'Australia', '789 Oak St.', 'markjohnson@company.com', 555111444, '1995-08-15', '2020-08-15', '1100.00', 26),
(4, 'Sarah', 'Lee', 'Female', 'South Korea', '321 Pine St.', 'sarahlee@company.com', 777888999, '1992-11-20', '2017-11-20', '1100.00', 29),
(5, 'David', 'Kim', 'Male', 'South Korea', '654 Maple St.', 'davidkim@company.com', 444555666, '1990-04-10', '2016-04-10', '1100.00', 31),
(6, 'Jessica', 'Brown', 'Female', 'USA', '789 Main St.', 'jessicabrown@company.com', 111222333, '1998-02-12', '2020-02-12', '1100.00', 23),
(7, 'Michael', 'Davis', 'Male', 'Canada', '456 Elm St.', 'michaeldavis@company.com', 333444555, '1993-07-25', '2018-07-25', '1100.00', 28),
(8, 'Emma', 'Wilson', 'Female', 'Australia', '123 Oak St.', 'emmawilson@company.com', 666777888, '1999-10-30', '2021-10-30', '1100.00', 22),
(9, 'Jason', 'Lee', 'Male', 'South Korea', '321 Pine St.', 'jasonlee@company.com', 222333444, '1997-03-17', '2021-03-17', '1100.00', 24),
(10, 'Sophia', 'Choi', 'Female', 'South Korea', '654 Maple St.', 'sophiachoi@company.com', 888999000, '1996-09-08', '2020-09-08', '1100.00', 25),
(11, 'William', 'Kim', 'Male', 'USA', '789 Main St.', 'williamkim@company.com', 444555666, '1992-12-12', '2017-12-12', '1300.00', 29),
(12, 'Olivia', 'Brown', 'Female', 'Canada', '456 Elm St.', 'oliviabrown@company.com', 111222333, '1994-06-22', '2019-06-22', '1300.00', 27),
(13, 'Ethan', 'Garcia', 'Male', 'USA', '123 Oak St.', 'ethangarcia@company.com', 333444555, '1991-03-05', '2016-03-05', '1300.00', 30),
(14, 'Ava', 'Wilson', 'Female', 'Australia', '321 Pine St.', 'avawilson@company.com', 666777888, '1997-11-10', '2020-11-10', '1300.00', 24),
(15, 'Noah', 'Lee', 'Male', 'South Korea', '654 Maple St.', 'noahlee@company.com', 222333444, '1993-04-01', '2018-04-01', '1300.00', 28),
(16, 'Mia', 'Choi', 'Female', 'South Korea', '789 Main St.', 'miachoi@company.com', 888999000, '1996-08-18', '2021-08-18', '1300.00', 25),
(17, 'James', 'Kim', 'Male', 'USA', 'Sidon', 'jameskim@company.com', 444555666, '1995-05-05', '2020-05-05', '1300.00', 26),
(18, 'Emily', 'Brown', 'Female', 'Canada', '123 Oak St.', 'emilybrown@company.com', 111222333, '1999-09-09', '2021-09-09', '1300.00', 22),
(19, 'Daniel', 'Garcia', 'Male', 'USA', '321 Pine St.', 'danielgarcia@company.com', 333444555, '1994-02-22', '2019-02-22', '1300.00', 27),
(20, 'Chloe', 'Wilson', 'Female', 'Australia', '654 Maple St.', 'chloewilson@company.com', 666777888, '1998-11-11', '2020-11-11', '1300.00', 23),
(21, 'hadi', 'sh7aade', 'male', 'Lebanese', 'Tripoli', 'hs@gmail.com', 78654321, '2002-05-01', '2023-05-04', '1100.00', 21),
(22, 'Sameer', 'youness', 'male', 'Lebanese', 'Bkaa3', 'sm@gmail.com', 78654368, '2003-04-01', '2023-05-04', '1300.00', 20);

-- --------------------------------------------------------

--
-- Table structure for table `marketing_domain`
--

CREATE TABLE `marketing_domain` (
  `Emp_ID` int(11) NOT NULL,
  `marketing_domain` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marketing_domain`
--

INSERT INTO `marketing_domain` (`Emp_ID`, `marketing_domain`) VALUES
(1, 'Makeup'),
(1, 'Phones'),
(2, 'Clean_Products'),
(2, 'Clothes'),
(3, 'Fitness_Products'),
(3, 'Home_decor'),
(3, 'Pet_Supplies'),
(4, 'Books'),
(4, 'Makeup'),
(4, 'Phones'),
(5, 'Desktops'),
(5, 'Phones'),
(6, 'Home_decor'),
(7, 'Books'),
(7, 'Makeup'),
(7, 'Phones'),
(8, 'Clean_Products'),
(8, 'Clothes'),
(8, 'Desktops'),
(9, 'Pet_Supplies'),
(10, 'Books'),
(10, 'Makeup'),
(10, 'Phones'),
(21, 'Desktops'),
(21, 'Phones'),
(22, 'Clean_Products'),
(22, 'Clothes');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `Offer_ID` int(11) NOT NULL,
  `Begin_Date` date NOT NULL,
  `End_date` date NOT NULL,
  `Offer_description` varchar(200) NOT NULL,
  `Offer_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`Offer_ID`, `Begin_Date`, `End_date`, `Offer_description`, `Offer_price`) VALUES
(1, '2023-05-24', '2024-01-01', 'By one get one free', 1300),
(2, '2023-05-24', '2024-03-01', 'By 2 get the Third free', 36);

-- --------------------------------------------------------

--
-- Table structure for table `offer_order`
--

CREATE TABLE `offer_order` (
  `Offer_order_date` date NOT NULL,
  `Offer_order_number` int(11) NOT NULL,
  `Customer_email` varchar(50) NOT NULL,
  `Emp_ID` int(11) NOT NULL,
  `Offer_ID` int(11) NOT NULL,
  `Offer_order_total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offer_order`
--

INSERT INTO `offer_order` (`Offer_order_date`, `Offer_order_number`, `Customer_email`, `Emp_ID`, `Offer_ID`, `Offer_order_total_price`) VALUES
('2023-05-24', 1, 'john.petersin@gmail.com', 21, 1, '1350.00'),
('2023-05-24', 2, 'ma@gmail.com', 21, 2, '86.00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Product_ID` int(11) NOT NULL,
  `Product_date` date DEFAULT NULL,
  `Product_name` varchar(100) NOT NULL,
  `Product_price` decimal(10,2) NOT NULL,
  `Comp_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_ID`, `Product_date`, `Product_name`, `Product_price`, `Comp_name`) VALUES
(1, '2023-05-03', 'Lipstick', '10.99', 'ABC Company'),
(2, '2023-05-03', 'Mascara', '15.50', 'ABC Company'),
(3, '2023-05-03', 'Foundation', '20.75', 'ABC Company'),
(4, '2023-05-03', 'Blush', '12.00', 'Glamorous Cosmetics'),
(5, '2023-05-03', 'Eyeliner', '8.99', 'Glamorous Cosmetics'),
(6, '2023-05-03', 'Eyeshadow Palette', '25.99', 'Glamorous Cosmetics'),
(7, '2023-05-03', 'Harry Potter and the Philosopher\'s Stone', '12.99', 'DEF Company'),
(8, '2023-05-03', 'To Kill a Mockingbird', '8.50', 'DEF Company'),
(9, '2023-05-03', 'The Great Gatsby', '9.75', 'DEF Company'),
(11, '2023-05-03', 'Pride and Prejudice', '10.00', 'Bookworms Inc.'),
(12, '2023-05-03', 'Animal Farm', '6.99', 'Bookworms Inc.'),
(13, '2023-05-03', 'iPhone 13 Pro Max', '1299.99', 'GHI Company'),
(14, '2023-05-03', 'Samsung Galaxy S22', '999.50', 'GHI Company'),
(15, '2023-05-03', 'Google Pixel 7', '799.75', 'GHI Company'),
(16, '2023-05-03', 'OnePlus 10 Pro', '899.00', 'Electronics Emporium'),
(17, '2023-05-03', 'Xiaomi Mi 12', '899.99', 'Electronics Emporium'),
(18, '2023-05-03', 'Huawei P60 Pro', '1199.99', 'Electronics Emporium'),
(19, '2023-05-03', 'Dell XPS 15', '1699.99', 'TechTrendz LLC'),
(20, '2023-05-03', 'HP Spectre x360', '1399.50', 'TechTrendz LLC'),
(21, '2023-05-03', 'Apple iMac 27-inch', '1799.75', 'TechTrendz LLC'),
(22, '2023-05-03', 'Asus ROG Strix G15', '1299.00', 'TechTrendz LLC'),
(23, '2023-05-03', 'Lenovo ThinkPad X1 Carbon', '1399.99', 'TechTrendz LLC'),
(24, '2023-05-03', 'Acer Predator Orion 9000', '2999.99', 'TechTrendz LLC'),
(25, '2023-05-03', 'Hand Soap', '5.99', 'Clean Living Co.'),
(26, '2023-05-03', 'Dish Soap', '4.50', 'Clean Living Co.'),
(27, '2023-05-03', 'Laundry Detergent', '10.75', 'Clean Living Co.'),
(28, '2023-05-03', 'Surface Cleaner', '7.00', 'Clean Living Co.'),
(29, '2023-05-03', 'Glass Cleaner', '6.99', 'Clean Living Co.'),
(30, '2023-05-04', 'Shampoo', '10.00', 'Clorox');

-- --------------------------------------------------------

--
-- Table structure for table `product_order`
--

CREATE TABLE `product_order` (
  `Product_order_date` date NOT NULL,
  `Product_order_number` int(11) NOT NULL,
  `Customer_email` varchar(50) NOT NULL,
  `Emp_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Product_order_total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_order`
--

INSERT INTO `product_order` (`Product_order_date`, `Product_order_number`, `Customer_email`, `Emp_ID`, `Product_ID`, `Product_order_total_price`) VALUES
('2023-05-24', 1, 'mc@gmail.com', 17, 27, '54.00'),
('2023-05-24', 2, 'ce@gmail.com', 18, 25, '3049.00');

-- --------------------------------------------------------

--
-- Table structure for table `shippers`
--

CREATE TABLE `shippers` (
  `Emp_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shippers`
--

INSERT INTO `shippers` (`Emp_ID`) VALUES
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrators`
--
ALTER TABLE `administrators`
  ADD PRIMARY KEY (`Admin_email`);

--
-- Indexes for table `advertisers`
--
ALTER TABLE `advertisers`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`Comp_name`);

--
-- Indexes for table `concerning`
--
ALTER TABLE `concerning`
  ADD PRIMARY KEY (`Offer_ID`,`Product_ID`),
  ADD KEY `Product_ID` (`Product_ID`);

--
-- Indexes for table `creates`
--
ALTER TABLE `creates`
  ADD PRIMARY KEY (`Emp_ID`,`Offer_ID`),
  ADD KEY `Offer_ID` (`Offer_ID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`Customer_email`);

--
-- Indexes for table `delivery_places`
--
ALTER TABLE `delivery_places`
  ADD PRIMARY KEY (`Emp_ID`,`delivery_places`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Indexes for table `marketing_domain`
--
ALTER TABLE `marketing_domain`
  ADD PRIMARY KEY (`Emp_ID`,`marketing_domain`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`Offer_ID`);

--
-- Indexes for table `offer_order`
--
ALTER TABLE `offer_order`
  ADD PRIMARY KEY (`Emp_ID`,`Customer_email`,`Offer_ID`),
  ADD KEY `Customer_email` (`Customer_email`),
  ADD KEY `Offer_ID` (`Offer_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `Comp_name` (`Comp_name`);

--
-- Indexes for table `product_order`
--
ALTER TABLE `product_order`
  ADD PRIMARY KEY (`Emp_ID`,`Customer_email`,`Product_ID`),
  ADD KEY `Customer_email` (`Customer_email`),
  ADD KEY `Product_ID` (`Product_ID`);

--
-- Indexes for table `shippers`
--
ALTER TABLE `shippers`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `concerning`
--
ALTER TABLE `concerning`
  ADD CONSTRAINT `concerning_ibfk_1` FOREIGN KEY (`Offer_ID`) REFERENCES `offers` (`Offer_ID`),
  ADD CONSTRAINT `concerning_ibfk_2` FOREIGN KEY (`Product_ID`) REFERENCES `products` (`Product_ID`);

--
-- Constraints for table `creates`
--
ALTER TABLE `creates`
  ADD CONSTRAINT `creates_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employees` (`Emp_ID`),
  ADD CONSTRAINT `creates_ibfk_2` FOREIGN KEY (`Offer_ID`) REFERENCES `offers` (`Offer_ID`);

--
-- Constraints for table `offer_order`
--
ALTER TABLE `offer_order`
  ADD CONSTRAINT `offer_order_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employees` (`Emp_ID`),
  ADD CONSTRAINT `offer_order_ibfk_2` FOREIGN KEY (`Customer_email`) REFERENCES `customers` (`Customer_email`),
  ADD CONSTRAINT `offer_order_ibfk_3` FOREIGN KEY (`Offer_ID`) REFERENCES `offers` (`Offer_ID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`Comp_name`) REFERENCES `companies` (`Comp_name`);

--
-- Constraints for table `product_order`
--
ALTER TABLE `product_order`
  ADD CONSTRAINT `product_order_ibfk_1` FOREIGN KEY (`Emp_ID`) REFERENCES `employees` (`Emp_ID`),
  ADD CONSTRAINT `product_order_ibfk_2` FOREIGN KEY (`Customer_email`) REFERENCES `customers` (`Customer_email`),
  ADD CONSTRAINT `product_order_ibfk_3` FOREIGN KEY (`Product_ID`) REFERENCES `products` (`Product_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
