package control;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import model.administrators;
import model.advertisers;
import model.concerning;
import model.creates;
import model.customers;
import model.delivery_places;
import model.employees;
import model.marketing_domain;
import model.offer_order;
import model.offers;
import model.organizations;
import model.product_order;
import model.products;
import model.shippers;
public class Online_Shop_Database_Main {
    private Connection con;
    private Statement stm;
    
    private void connect() throws SQLException{
        con= DriverManager.getConnection("jdbc:mysql://localhost:3307/online_shop");
        stm=con.createStatement();
    }
    
    private void close() throws SQLException{
        stm.close();
        con.close();
    }
    public void addAdministrator(administrators admin){
        String query1="Insert into administrators values('"+admin.getF_name()+"','"+admin.getL_name()+"','"+admin.getAdmin_email()+"','" +
                admin.getAdmin_birth_date() + "','" +admin.getAdmin_age()+"','" +admin.getAdmin_sex()+"','"
                +admin.getAdmin_phone()+"','"+admin.getAdmin_address()+"','"+admin.getAdmin_nationality()+"')";
      System.out.println(query1);
        
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addCustomer(customers cs){
        String query1="Insert into customers values('"+cs.getF_name()+"','"+cs.getL_name()+"','"+cs.getCustomer_sex()+"','"
                +cs.getCustomer_nationality() +"','"+cs.getCustomer_birth_date()+"','"+cs.getCustomer_age()
                +"','"+cs.getCustomer_address()+"','"+cs.getCustomer_phone()+"','" + cs.getCustomer_email() + "')";
      System.out.println(query1);
        
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addAdvertiser(advertisers advertiser){
        String query1="Insert into advertisers values('" + advertiser.getEmp_ID()+"')";
        System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addShipper(shippers shipper){
        String query1="Insert into shippers values('" + shipper.getEmp_ID()+"')";
        System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addDeliveryPlaces(delivery_places dp){
        String query1="Insert into delivery_places values('" + dp.getEmp_ID()+"','"+ dp.getDelivery_places()+"')";
        System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addMarketingDomains(marketing_domain md){
        String query1="Insert into marketing_domain values('" + md.getEmp_ID()+"','"+ md.getMarketing_domain()+"')";
        System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    
    public void addAdvertiserCreatesOffer(creates cr){
        String query1="Insert into creates values('" + cr.getEmp_ID()+"','"+ cr.getOffer_ID()+"')";
        System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addOfferConcerningProcuct(concerning cn){
        String query1="Insert into concerning values('" + cn.getOffer_ID()+"','"+ cn.getProduct_ID()+"')";
        System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addOffer(offers of){
      String query1 = "INSERT INTO offers VALUES ('" + 
              of.getOffer_ID() + "','" + of.getBegin_Date() + "','" + of.getEnd_date()
              + "','" + of.getOffer_description() + "','" + of.getOffer_price() + "')";
      System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    
    public void addOrganization(organizations org){
      String query1="Insert into companies values('"+org.getOrg_name()+"','"+org.getOrg_address()+"','"+org.getOrg_nationality()+"','"
                + org.getOrg_email()+"','" + org.getOrg_Phone()+"','"+ org.getType_of_products() +"')";
      System.out.println(query1);
        
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addProduct(products pr){
      String query1="Insert into products values('"+pr.getProduct_ID()+"','" + pr.getDate() + "','" +pr.getProduct_name()+"','"+pr.getProduct_price() +"','" +pr.getOrg_name()+"')";
      System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    
    public void addProductOrder(product_order po){   
      String query1="Insert into product_order values('" + po.getProduct_order_date()+ "','" + 
              po.getProduct_order_number() + "','" +po.getCostumer_email()+"','"+po.getEmp_ID()+ "','" +po.getProduct_ID() 
              +"','" + po.getProduct_order_total_price() +"')";
      System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addOffertOrder(offer_order fo){   
      String query1="Insert into offer_order values('" + fo.getOffer_order_date()+"','" +  fo.getOffer_order_number() +
              "','" +fo.getCostumer_email()+"','"+fo.getEmp_ID()+ "','" +fo.getOffer_ID()+"','" + fo.getOffer_order_total_price() +"')";
      System.out.println(query1);
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public void addEmployee(employees employee){
        String query1="Insert into employees values('"+ employee.getEmp_ID()+ "','"+employee.getF_name()+"','"+employee.getL_name()+"','"+employee.getEmp_sex()+"','" + employee.getEmp_Nationality() + "','" + employee.getEmp_address()+"','"
                + employee.getEmp_email()+"','"+employee.getEmp_phone()+ "','" + employee.getEmp_birth_date_String()+ "','" + employee.getHiring_date_String() + "','" + employee.getSalary() + "','" + employee.getEmp_Age()+ "')";
      System.out.println(query1);
        
        try{
            connect();
            stm.executeUpdate(query1);
            close();
        }
        catch (SQLException e){
            Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, e);
        }
    }
    public ArrayList<String> getALLAdminstrators_emails() throws SQLException{
     String query2="Select Admin_email from administrators";
     ArrayList<String> emailList = new ArrayList();
     
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             emailList.add(rs.getString("Admin_email"));
         
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return emailList;
    }
    public ArrayList<String> getALLProductsNames() throws SQLException{
     String query2="Select Product_name from Products";
     ArrayList<String> names = new ArrayList();
     
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             names.add(rs.getString("Product_name"));
         
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return names;
    }
    public ArrayList<Integer> getALLOfferIDs() throws SQLException{
     String query2="Select Offer_ID from Offers";
     ArrayList<Integer> id = new ArrayList();
     
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             id.add(rs.getInt("Offer_Id"));
         
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return id;
    }
    public ArrayList<Integer> getALLProductsIDsByName_NotInOffer(String name) throws SQLException{
     //String query2 = "SELECT Product_id FROM Products WHERE Product_name = '" + name + "'";
     String query = "SELECT p.Product_id "
                 + "FROM Products p "
                 + "LEFT JOIN Concerning c ON p.Product_id = c.Product_id "
                 + "WHERE p.Product_name = ? AND c.Product_id IS NULL";
     ArrayList<Integer> ids = new ArrayList();
     try{
        connect();
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
      //   connect();
     //    ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             ids.add(rs.getInt("Product_ID"));
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return ids;
    }
    public ArrayList<Integer> getALLProductsIDsByName(String name) throws SQLException{
     String query = "SELECT Product_id FROM Products WHERE Product_name = ?";
     ArrayList<Integer> ids = new ArrayList();
     try{
        connect();
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        // ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             ids.add(rs.getInt("Product_ID"));
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return ids;
    }
    public ArrayList<Integer> getALLProductsIDs() throws SQLException{
     String query2 = "SELECT Product_id FROM Products";
     ArrayList<Integer> ids = new ArrayList();
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             ids.add(rs.getInt("Product_ID"));
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return ids;
    }
    public void UpdateProduct(int Product_ID, String Product_name, double Product_price, String Org_name, String d) {
       String query = "UPDATE products SET Product_ID='" + Product_ID + "', Product_date='" + d +
        "', Product_name='" + Product_name + "', Product_price='" + Product_price + "', Comp_name='" + Org_name + "'";
         try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    
    public products getProductByID(int id){
        String query="SELECT * FROM products WHERE Product_ID='"+id+"'";
        products pr=null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         if(rs.next())
         {
             pr = new products();
             pr.setProduct_ID(id);
             pr.setDate(rs.getString("Product_date"));
             pr.setProduct_name(rs.getString("Product_name"));
             pr.setProduct_price(rs.getInt("Product_price"));
             pr.setOrg_name(rs.getString("Comp_name"));
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    return pr;
    }
    public int getProductPrice(String name) throws SQLException{
     String query2 = "SELECT Product_price FROM Products WHERE Product_name = '" + name + "'";
     int price = 0;
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         if(rs.next()){
             price+= rs.getInt("Product_price");
             
         }   
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return price ;
    }
    public String getCustomerAddress(String email) throws SQLException{
     String query2="SELECT Customer_address FROM customers WHERE Customer_email = " + email+ "'";
     String address="";
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         if(rs.next()){
             address+= rs.getInt("Customer_address");
         }   
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return address ;
    }
    public ArrayList<employees> getAllShipperEmployeesByAddressOfDeliveryPlace(String add){//Select Emp_ID from advertisers
        String query = "SELECT * FROM employees NATURAL JOIN delivery_places WHERE delivery_places='" + add + "' AND Emp_ID IN (SELECT Emp_ID FROM shippers)";
        ArrayList<employees> emplist= new ArrayList<employees>();
        employees emp = null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         while(rs.next()){
             emp = new employees();
             emp.setEmp_ID(rs.getInt("Emp_ID"));
             emp.setF_name(rs.getString("F_name"));
             emp.setL_name(rs.getString("L_name"));
             emp.setEmp_sex(rs.getString("Emp_sex"));
             emp.setEmp_Nationality(rs.getString("Emp_nationality"));
             emp.setEmp_address(rs.getString("Emp_address"));
             emp.setEmp_email(rs.getString("Emp_email"));
             emp.setEmp_phone(rs.getInt("Emp_phone"));
             emp.setEmp_birth_date_String(rs.getString("Emp_birth_date"));
             emp.setHiring_date_String(rs.getString("hiring_date"));
             emp.setSalary(rs.getInt("salary"));
             emplist.add(emp);
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
         return emplist;
    }
    public ArrayList<employees> getAllShipperEmployees(){
        String query = "SELECT employees.*, shippers.Emp_ID FROM employees, shippers WHERE employees.Emp_ID = shippers.Emp_ID";
        ArrayList<employees> emplist= new ArrayList<employees>();
        employees emp = null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         while(rs.next()){
             emp = new employees();
             emp.setEmp_ID(rs.getInt("Emp_ID"));
             emp.setF_name(rs.getString("F_name"));
             emp.setL_name(rs.getString("L_name"));
             emp.setEmp_sex(rs.getString("Emp_sex"));
             emp.setEmp_Nationality(rs.getString("Emp_nationality"));
             emp.setEmp_address(rs.getString("Emp_address"));
             emp.setEmp_email(rs.getString("Emp_email"));
             emp.setEmp_phone(rs.getInt("Emp_phone"));
             emp.setEmp_birth_date_String(rs.getString("Emp_birth_date"));
             emp.setHiring_date_String(rs.getString("hiring_date"));
             emp.setSalary(rs.getInt("salary")); 
             emplist.add(emp);
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
         return emplist;
    }
    public int getMaxProductsID() throws SQLException {
    String query = "SELECT MAX(product_ID) FROM products";
    int max = 0;
     
    try {
        connect();
        ResultSet rs = stm.executeQuery(query);
        if (rs.next()) {
            max = rs.getInt(1);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
    } 
    close();
    return max;
    }
    public int getMaxProductOrderNumber() throws SQLException {
    String query = "SELECT MAX(Product_order_number) FROM Product_order";
    int max = 0;
    try {
        connect();
        ResultSet rs = stm.executeQuery(query);
        if (rs.next()) {
            max = rs.getInt(1);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
    } 
    close();
    return max;
    }
    public int getMaxOfferOrderNumber() throws SQLException {
    String query = "SELECT MAX(Offer_order_number) FROM Offer_order";
    int max = 0;
    try {
        connect();
        ResultSet rs = stm.executeQuery(query);
        if (rs.next()) {
            max = rs.getInt(1);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
    } 
    close();
    return max;
    }
    public int getMaxProductsIDByName(String n) throws SQLException {
    String query = "SELECT MAX(product_ID) FROM products WHERE Product_name = '" + n + "'";
    int max = 0;
     
    try {
        connect();
        ResultSet rs = stm.executeQuery(query);
        if (rs.next()) {
            max = rs.getInt(1);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
    } 
    close();
    return max;
    }

     public int getMaxOfferID() throws SQLException {
    String query = "SELECT MAX(Offer_ID) FROM offers";
    int max = 0;
    try {
        connect();
        ResultSet rs = stm.executeQuery(query);
        if (rs.next()) {
            max = rs.getInt(1);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
    } 
    close();
    return max;
    }
   public int getMaxEmployeeID() throws SQLException {
    String query = "SELECT MAX(Emp_ID) FROM employees";
    int max = 0;
     
    try {
        connect();
        ResultSet rs = stm.executeQuery(query);
        if (rs.next()) {
            max = rs.getInt(1);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
    } 
    close();
    return max;
    }
   public customers getCustomerByemail(String m){
        String query="SELECT * FROM customers WHERE Customer_email=?";
        customers cs=null;
         try{
         connect();
        // 
         PreparedStatement statement = con.prepareStatement(query);
         statement.setString(1, m);
         ResultSet rs= statement.executeQuery();
         if(rs.next())
         {
             cs = new customers();
             cs.setF_name(rs.getString("F_name"));
             cs.setL_name(rs.getString("L_name"));
             cs.setCustomer_email(rs.getString("Customer_email"));
             cs.setCustomer_sex(rs.getString("Customer_sex"));
             cs.setCustomer_phone(rs.getInt("Customer_phone"));
             cs.setCustomer_address(rs.getString("Customer_address"));
             cs.setCustomer_nationality(rs.getString("Customer_nationality"));
             cs.setCustomer_birth_date(rs.getString("Customer_birth_date"));
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    return cs;
    }
    public administrators getAdministratorByEmail(String email){
        String query="SELECT * FROM administrators WHERE Admin_email='"+email+"'";
        administrators admin=null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         if(rs.next())
         {
             admin = new administrators();
             admin.setF_name(rs.getString("F_name"));
             admin.setL_name(rs.getString("L_name"));
             admin.setAdmin_email(rs.getString("Admin_email"));
             admin.setAdmin_birth_date(rs.getString("Admin_birth_date"));
             admin.setAdmin_sex(rs.getString("Admin_sex"));
             admin.setAdmin_phone(rs.getInt("Admin_phone"));
             admin.setAdmin_address(rs.getString("Admin_address"));
             admin.setAdmin_nationality(rs.getString("Admin_nationality"));   
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    return admin;
    }
    public employees getEmployeeByID(int id){
        String query="SELECT * FROM employees WHERE Emp_ID='"+id+"'";
        employees emp=null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         if(rs.next())
         {
             emp = new employees();
             emp.setEmp_ID(id);
             emp.setF_name(rs.getString("F_name"));
             emp.setL_name(rs.getString("L_name"));
             emp.setEmp_sex(rs.getString("Emp_sex"));
             emp.setEmp_Nationality(rs.getString("Emp_nationality"));
             emp.setEmp_address(rs.getString("Emp_address"));
             emp.setEmp_email(rs.getString("Emp_email"));
             emp.setEmp_phone(rs.getInt("Emp_phone"));
             emp.setEmp_birth_date_String(rs.getString("Emp_birth_date"));
             emp.setHiring_date_String(rs.getString("hiring_date"));
             emp.setSalary(rs.getInt("salary")); 
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    return emp;
    }
     public offers getOfferByID(int id){
        String query="SELECT * FROM offers WHERE Offer_ID='"+id+"'";
        offers emp=null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         if(rs.next())
         {
             emp = new offers();
             emp.setOffer_ID(id);
             emp.setBegin_Date(rs.getString("Begin_date"));
             emp.setEnd_date(rs.getString("End_date"));
             emp.setOffer_description(rs.getString("Offer_description"));
             emp.setOffer_price(rs.getInt("Offer_price"));
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    return emp;
    }
    public ArrayList<Integer> getALLEmployeesIDs() throws SQLException{
     String query2="Select Emp_ID from employees";
     ArrayList<Integer> IDList = new ArrayList();
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             IDList.add(rs.getInt("Emp_ID"));
         
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return IDList;
    }
    public ArrayList<Integer> getALLAdvertisersIDs() throws SQLException{
     String query2="Select Emp_ID from advertisers";
     ArrayList<Integer> ad_IDList = new ArrayList();
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             ad_IDList.add(rs.getInt("Emp_ID"));
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return ad_IDList;
    }
    
    public void deleteEmployeeByID(int id){
        String query="DELETE FROM employees where ID="+ id;
        try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    public void deleteOrganizationByName(String n) throws SQLException {
          String query = "DELETE FROM companies WHERE Comp_name=?";
        try{
         connect();
        PreparedStatement statement = con.prepareStatement(query);
        statement.setString(1, n);
        statement.executeUpdate();
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    public ArrayList<String> getALLOrganizationsNames() throws SQLException{
     String query2="Select Comp_name from companies";
     ArrayList<String> List = new ArrayList();
     try{
         connect();
         ResultSet rs= stm.executeQuery(query2);
         while(rs.next())
             List.add(rs.getString("Comp_name"));
         
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
     return List;
    }
      public organizations getOrganizationByName(String email){
        String query="SELECT * FROM companies WHERE Comp_name='"+email+"'";
        organizations org=null;
         try{
         connect();
         ResultSet rs= stm.executeQuery(query);
         if(rs.next())
         {
             org = new organizations();
             org.setOrg_name(rs.getString("Comp_name"));
             org.setOrg_address(rs.getString("Comp_address"));
             org.setOrg_nationality(rs.getString("Comp_nationality"));
             org.setOrg_email(rs.getString("Comp_email"));
             org.setOrg_Phone(rs.getInt("Comp_phone"));
             org.setType_of_products(rs.getString("type_of_products"));
         }
         close();
     }
     catch (SQLException ex)
     {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    return org;
    }
    public void deleteOfferByID(int id){
        String query="DELETE FROM offers where Offer_ID="+ id;
        try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    public void deleteProductByID(int id) {
    String query = "DELETE FROM products WHERE Product_ID = ?";
    try {
        connect();
        PreparedStatement pstmt = con.prepareStatement(query);
        pstmt.setInt(1, id);
        pstmt.executeUpdate();
        pstmt.close();
        close();
    } catch (SQLException ex) {
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE, null, ex);
     }
    }
    public void deleteshipperByID(int id){
        String query="DELETE FROM shippers where Emp_ID="+ id;
        try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    public void deleteAdvertiserByID(int id){
        String query="DELETE FROM advertisers where Emp_ID="+ id;
        try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    
    public void Updateadministrator(String Admin_email, String Admin_sex, int Admin_phone, String Admin_address, String F_name, String L_name, String Admin_nationality){
        String query="UPDATE administrators SET Admin_sex='" + Admin_sex + "', Admin_phone=" + Admin_phone
                + ", Admin_address='" + Admin_address + "', F_name='" + F_name + "', L_name='" + L_name + "', Admin_nationality='" + Admin_nationality + "' WHERE Admin_email='" + Admin_email + "'";
                
        try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    public void UpdateEmployee(String nationality,int Emp_ID, String Emp_address, double salary, String F_name, String L_name, 
            String Emp_email, int Emp_phone, String Emp_sex, String Emp_birth_date_String, String hiring_date_String) {
       String query = "UPDATE employees SET Emp_sex='" + Emp_sex + "', Emp_phone=" + Emp_phone +
               ", Emp_address='" + Emp_address + "', F_name='" + F_name + "', L_name='" + L_name +
               "', Emp_nationality='" + nationality + "', salary=" + salary + " WHERE Emp_ID='" + Emp_ID + "'";
         try{
         connect();
         stm.executeUpdate(query);
         close();
        }
        catch (SQLException ex){
        Logger.getLogger(Online_Shop_Database_Main.class.getName()).log(Level.SEVERE,null, ex);
     }
    }
    
}