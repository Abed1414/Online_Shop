package control;
import java.sql.*;
import view.Administrator_Registration;
public class Online_Shop_Administrator_Registration {
    private Connection con;
    private Statement stm;
    
    private void connect() throws SQLException{
        con= DriverManager.getConnection("jdbc:mysql://localhost:3307/online_shop");
        stm=con.createStatement();
    }
    
    private void close() throws SQLException{
        stm.close();
        con.close();
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Administrator_Registration().setVisible(true); // replace MyFrame with the name of your Java frame
            }
        });
    }
}