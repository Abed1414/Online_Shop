package model;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
public class customers {
private String Customer_email;
private String F_name;
private String L_name;
private String Customer_sex;
private String Customer_nationality;
private int Customer_phone;
private String Customer_birth_date;
private int Customer_age;
private String Customer_address;

    public customers() {
    }

    public String getCustomer_address() {
        return Customer_address;
    }

    public void setCustomer_address(String Customer_address) {
        this.Customer_address = Customer_address;
    }
    public customers(String Customer_address,String Customer_email, String F_name, String L_name, String Customer_sex, String Customer_nationality, int Customer_phone, String Customer_birth_date) {
        this.Customer_email = Customer_email;
        this.F_name = F_name;
        this.L_name = L_name;
        this.Customer_sex = Customer_sex;
        this.Customer_nationality = Customer_nationality;
        this.Customer_phone = Customer_phone;
        this.Customer_birth_date = Customer_birth_date;
        this.Customer_address=Customer_address;
        setAge(Customer_birth_date);
    }

    public String getCustomer_email() {
        return Customer_email;
    }

    public void setCustomer_email(String Customer_email) {
        this.Customer_email = Customer_email;
    }

    public String getF_name() {
        return F_name;
    }

    public void setF_name(String F_name) {
        this.F_name = F_name;
    }

    public String getL_name() {
        return L_name;
    }

    public void setL_name(String L_name) {
        this.L_name = L_name;
    }

    public String getCustomer_sex() {
        return Customer_sex;
    }

    public void setCustomer_sex(String Customer_sex) {
        this.Customer_sex = Customer_sex;
    }

    public String getCustomer_nationality() {
        return Customer_nationality;
    }

    public void setCustomer_nationality(String Customer_nationality) {
        this.Customer_nationality = Customer_nationality;
    }

    public int getCustomer_phone() {
        return Customer_phone;
    }

    public void setCustomer_phone(int Customer_phone) {
        this.Customer_phone = Customer_phone;
    }

    public String getCustomer_birth_date() {
        return Customer_birth_date;
    }

    public void setCustomer_birth_date(String Customer_birth_date) {
        this.Customer_birth_date = Customer_birth_date;
    }

    public int getCustomer_age() {
        return Customer_age;
    }

    public void setCustomer_age(int Customer_age) {
        this.Customer_age = Customer_age;
    }
    public void setAge(String Customer_birth_date) {
    LocalDate today = LocalDate.now();
    LocalDate dateOfBirth = LocalDate.parse(Customer_birth_date);
    Period period = Period.between(dateOfBirth, today);
    Customer_age = period.getYears(); 
    }
}
