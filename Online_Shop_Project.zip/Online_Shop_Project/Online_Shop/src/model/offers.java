package model;
import java.util.Date;
public class offers {
    private int Offer_ID;
    private String Offer_description;
    private double Offer_price; 
    private String Begin_Date;
    private String End_date;

    public offers(int Offer_ID, String Offer_description, double Offer_price, String Begin_Date, String End_date) {
        this.Offer_ID = Offer_ID;
        this.Offer_description = Offer_description;
        this.Offer_price = Offer_price;
        this.Begin_Date = Begin_Date;
        this.End_date = End_date;
    }

    public offers() {
    }

    public offers(int Offer_ID) {
        this.Offer_ID = Offer_ID;
    }

    public int getOffer_ID() {
        return Offer_ID;
    }

    public void setOffer_ID(int Offer_ID) {
        this.Offer_ID = Offer_ID;
    }

    public String getOffer_description() {
        return Offer_description;
    }

    public void setOffer_description(String Offer_description) {
        this.Offer_description = Offer_description;
    }

    public double getOffer_price() {
        return Offer_price;
    }

    public void setOffer_price(double Offer_price) {
        this.Offer_price = Offer_price;
    }

    public String getBegin_Date() {
        return Begin_Date;
    }

    public void setBegin_Date(String Begin_Date) {
        this.Begin_Date = Begin_Date;
    }

    public String getEnd_date() {
        return End_date;
    }

    public void setEnd_date(String End_date) {
        this.End_date = End_date;
    }
    
    
}
