package model;
public class shippers {
 private int Emp_ID;
    public shippers(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }
    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

}
