package model;
public class organizations {
//,  , , , , 
private String Org_name;
private String Org_nationality;
private String type_of_products;
private int Org_Phone;
private String Org_address;
private String Org_email;

    public organizations() {
    }

    public organizations(String Org_name, String Org_nationality, String type_of_products, int Org_Phone, String Org_address, String Org_email) {
        this.Org_name = Org_name;
        this.Org_nationality = Org_nationality;
        this.type_of_products = type_of_products;
        this.Org_Phone = Org_Phone;
        this.Org_address = Org_address;
        this.Org_email = Org_email;
    }

    public String getOrg_name() {
        return Org_name;
    }

    public void setOrg_name(String Org_name) {
        this.Org_name = Org_name;
    }

    public String getOrg_nationality() {
        return Org_nationality;
    }

    public void setOrg_nationality(String Org_nationality) {
        this.Org_nationality = Org_nationality;
    }

    public String getType_of_products() {
        return type_of_products;
    }

    public void setType_of_products(String type_of_products) {
        this.type_of_products = type_of_products;
    }

    public int getOrg_Phone() {
        return Org_Phone;
    }

    public void setOrg_Phone(int Org_Phone) {
        this.Org_Phone = Org_Phone;
    }

    public String getOrg_address() {
        return Org_address;
    }

    public void setOrg_address(String Org_address) {
        this.Org_address = Org_address;
    }

    public String getOrg_email() {
        return Org_email;
    }

    public void setOrg_email(String Org_email) {
        this.Org_email = Org_email;
    }

}
