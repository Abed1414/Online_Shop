package model;
public class marketing_domain {
private int Emp_ID;
private String marketing_domain;
    public marketing_domain(int Emp_ID, String marketing_domain) {
        this.Emp_ID = Emp_ID;
        this.marketing_domain = marketing_domain;
    }

    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public String getMarketing_domain() {
        return marketing_domain;
    }

    public void setMarketing_domain(String marketing_domain) {
        this.marketing_domain = marketing_domain;
    }
}
