package model;

import java.time.LocalDate;
import java.time.Period;

public class administrators {
    private String Admin_email;
    private String Admin_sex;
    private int Admin_phone;
    private String Admin_address;
    private String F_name;
    private String Admin_birth_date;
    private int Admin_age;
    
    public void setAge(String Admin_birth_date) {
    LocalDate today = LocalDate.now();
    LocalDate dateOfBirth = LocalDate.parse(Admin_birth_date);
    Period period = Period.between(dateOfBirth, today);
    Admin_age = period.getYears(); 
    }
    public int getAdmin_age() {
        return Admin_age;
    }

    public String getAdmin_birth_date() {
        return Admin_birth_date;
    }

    public void setAdmin_birth_date(String Admin_birth_date) {
        this.Admin_birth_date = Admin_birth_date;
         setAge(Admin_birth_date);
    }

    public administrators() {
    }

    public administrators(String Admin_email, String Admin_sex, int Admin_phone, String Admin_address, String F_name, String L_name, String Admin_nationality, String birth_date) {
        this.Admin_email = Admin_email;
        this.Admin_sex = Admin_sex;
        this.Admin_phone = Admin_phone;
        this.Admin_address = Admin_address;
        this.F_name = F_name;
        this.L_name = L_name;
        this.Admin_nationality = Admin_nationality;
        Admin_birth_date= birth_date;
        setAge(Admin_birth_date);
        
    } 
    
    public administrators(String Admin_email, String F_name, String L_name) {
        this.Admin_email = Admin_email;
        this.F_name = F_name;
        this.L_name = L_name;
    }

    public void setAdmin_email(String Admin_email) {
        this.Admin_email = Admin_email;
    }

    public void setAdmin_sex(String Admin_sex) {
        this.Admin_sex = Admin_sex;
    }

    public void setAdmin_phone(int Admin_phone) {
        this.Admin_phone = Admin_phone;
    }

    public void setAdmin_address(String Admin_address) {
        this.Admin_address = Admin_address;
    }

    public void setF_name(String F_name) {
        this.F_name = F_name;
    }

    public void setL_name(String L_name) {
        this.L_name = L_name;
    }

    public void setAdmin_nationality(String Admin_nationality) {
        this.Admin_nationality = Admin_nationality;
    }
    private String L_name;
    private String Admin_nationality;

    public String getAdmin_email() {
        return Admin_email;
    }

    public String getAdmin_sex() {
        return Admin_sex;
    }

    public int getAdmin_phone() {
        return Admin_phone;
    }

    public String getAdmin_address() {
        return Admin_address;
    }

    public String getF_name() {
        return F_name;
    }

    public String getL_name() {
        return L_name;
    }

    public String getAdmin_nationality() {
        return Admin_nationality;
    }
}
