package model;
public class creates {
private int Emp_ID;
private int Offer_ID;

    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public int getOffer_ID() {
        return Offer_ID;
    }

    public void setOffer_ID(int Offer_ID) {
        this.Offer_ID = Offer_ID;
    }

    public creates(int Emp_ID, int Offer_ID) {
        this.Emp_ID = Emp_ID;
        this.Offer_ID = Offer_ID;
    }
}