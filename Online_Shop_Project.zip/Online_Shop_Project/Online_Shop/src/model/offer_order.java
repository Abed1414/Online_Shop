package model;
import java.util.Date;
public class offer_order {
private int Emp_ID;
private String Costumer_email;
private int Offer_ID;
private String Offer_order_date;
private double Offer_order_total_price;
private int Offer_order_number;

    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public String getCostumer_email() {
        return Costumer_email;
    }

    public void setCostumer_email(String Costumer_email) {
        this.Costumer_email = Costumer_email;
    }

    public int getOffer_ID() {
        return Offer_ID;
    }

    public void setOffer_ID(int Offer_ID) {
        this.Offer_ID = Offer_ID;
    }

    public String getOffer_order_date() {
        return Offer_order_date;
    }

    public void setOffer_order_date(String Offer_order_date) {
        this.Offer_order_date = Offer_order_date;
    }

    public double getOffer_order_total_price() {
        return Offer_order_total_price;
    }

    public void setOffer_order_total_price(double Offer_order_total_price) {
        this.Offer_order_total_price = Offer_order_total_price;
    }

    public int getOffer_order_number() {
        return Offer_order_number;
    }

    public void setOffer_order_number(int Offer_order_number) {
        this.Offer_order_number = Offer_order_number;
    }

    public offer_order(int Emp_ID, String Costumer_email, int Offer_ID, String Offer_order_date, double Offer_order_total_price, int Offer_order_number) {
        this.Emp_ID = Emp_ID;
        this.Costumer_email = Costumer_email;
        this.Offer_ID = Offer_ID;
        this.Offer_order_date = Offer_order_date;
        this.Offer_order_total_price = Offer_order_total_price;
        this.Offer_order_number = Offer_order_number;
    }

}
