package model;
public class concerning {
private int Offer_ID;
private int Product_ID;

    public int getOffer_ID() {
        return Offer_ID;
    }

    public void setOffer_ID(int Offer_ID) {
        this.Offer_ID = Offer_ID;
    }

    public int getProduct_ID() {
        return Product_ID;
    }

    public void setProduct_ID(int Product_ID) {
        this.Product_ID = Product_ID;
    }

    public concerning(int Offer_ID, int Product_ID) {
        this.Offer_ID = Offer_ID;
        this.Product_ID = Product_ID;
    }
}
