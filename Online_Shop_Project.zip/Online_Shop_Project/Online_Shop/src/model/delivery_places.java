package model;
public class delivery_places {
 private int Emp_ID;
 private String delivery_places;
    public delivery_places(int Emp_ID, String delivery_places) {
        this.Emp_ID = Emp_ID;
        this.delivery_places = delivery_places;
    }
    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public String getDelivery_places() {
        return delivery_places;
    }

    public void setDelivery_places(String delivery_places) {
        this.delivery_places = delivery_places;
    }
}