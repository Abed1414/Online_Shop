package model;
public class products {
private int Product_ID;
private String Product_name;
private double Product_price;
private String Org_name;
private String date;

    public products() {
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getProduct_ID() {
        return Product_ID;
    }

    public void setProduct_ID(int Product_ID) {
        this.Product_ID = Product_ID;
    }

    public String getProduct_name() {
        return Product_name;
    }

    public void setProduct_name(String Product_name) {
        this.Product_name = Product_name;
    }

    public double getProduct_price() {
        return Product_price;
    }

    public void setProduct_price(double Product_price) {
        this.Product_price = Product_price;
    }

    public String getOrg_name() {
        return Org_name;
    }

    public void setOrg_name(String Org_name) {
        this.Org_name = Org_name;
    }

    public products(int Product_ID, String Product_name, double Product_price, String Org_name, String d) {
        this.Product_ID = Product_ID;
        this.Product_name = Product_name;
        this.Product_price = Product_price;
        this.Org_name = Org_name;
        date=d;
    }

}
