package model;

import java.util.Date;

public class product_order {
//(#, #, #, , , 
private int Emp_ID;
private String Costumer_email;
private int Product_ID;
private String Product_order_date;
private int Product_order_number;
private double Product_order_total_price;

    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public String getCostumer_email() {
        return Costumer_email;
    }

    public void setCostumer_email(String Costumer_email) {
        this.Costumer_email = Costumer_email;
    }

    public int getProduct_ID() {
        return Product_ID;
    }

    public void setProduct_ID(int Product_ID) {
        this.Product_ID = Product_ID;
    }

    public String getProduct_order_date() {
        return Product_order_date;
    }

    public void setProduct_order_date(String Product_order_date) {
        this.Product_order_date = Product_order_date;
    }

    public int getProduct_order_number() {
        return Product_order_number;
    }

    public void setProduct_order_number(int Product_order_number) {
        this.Product_order_number = Product_order_number;
    }

    public double getProduct_order_total_price() {
        return Product_order_total_price;
    }

    public void setProduct_order_total_price(double Product_order_total_price) {
        this.Product_order_total_price = Product_order_total_price;
    }

    public product_order(int Emp_ID, String Costumer_email, int Product_ID, String Product_order_date, int Product_order_number, double Product_order_total_price) {
        this.Emp_ID = Emp_ID;
        this.Costumer_email = Costumer_email;
        this.Product_ID = Product_ID;
        this.Product_order_date = Product_order_date;
        this.Product_order_number = Product_order_number;
        this.Product_order_total_price = Product_order_total_price;
    }

}
