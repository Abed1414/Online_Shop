package model;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

public class employees { 
private int Emp_ID;
private String Emp_address;
private double salary;
private String F_name;
private String L_name;
private String Emp_email;
private int Emp_phone;
private String Emp_sex;
private String Emp_Nationality;

    public String getEmp_Nationality() {
        return Emp_Nationality;
    }

    public void setEmp_Nationality(String Emp_Nationality) {
        this.Emp_Nationality = Emp_Nationality;
    }
private String Emp_birth_date_String;
private String hiring_date_String;

    public employees() {
    }

    

    public String getEmp_birth_date_String() {
        return Emp_birth_date_String;
    }

    public void setEmp_birth_date_String(String Emp_birth_date_String) {
        this.Emp_birth_date_String = Emp_birth_date_String;
        setAge(Emp_birth_date_String);
    }

    public String getHiring_date_String() {
        return hiring_date_String;
    }

    public void setHiring_date_String(String hiring_date_String) {
        this.hiring_date_String = hiring_date_String;
    }
private int Emp_Age;

    public int getEmp_Age() {
        return Emp_Age;
    }

    public void setEmp_Age(int Emp_Age) {
        this.Emp_Age = Emp_Age;
    }
    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public employees(String nationality,int Emp_ID, String Emp_address, double salary, String F_name, String L_name, 
            String Emp_email, int Emp_phone, String Emp_sex, String Emp_birth_date_String, String hiring_date_String) {
        Emp_Nationality=nationality;
        this.Emp_ID = Emp_ID;
        this.Emp_address = Emp_address;
        this.salary = salary;
        this.F_name = F_name;
        this.L_name = L_name;
        this.Emp_email = Emp_email;
        this.Emp_phone = Emp_phone;
        this.Emp_sex = Emp_sex;
        this.Emp_birth_date_String=Emp_birth_date_String;
        this.hiring_date_String=hiring_date_String;
        setAge(Emp_birth_date_String);
        
    }
    public void setEmp_address(String Emp_address) {
        this.Emp_address = Emp_address;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setF_name(String F_name) {
        this.F_name = F_name;
    }

    public void setL_name(String L_name) {
        this.L_name = L_name;
    }

    public void setEmp_email(String Emp_email) {
        this.Emp_email = Emp_email;
    }

    public void setEmp_phone(int Emp_phone) {
        this.Emp_phone = Emp_phone;
    }

    public void setEmp_sex(String Emp_sex) {
        this.Emp_sex = Emp_sex;
    }

    public int getEmp_ID() {
        return Emp_ID;
    }
    public void setAge(String Emp_birth_date_String) {
    LocalDate today = LocalDate.now();
    LocalDate dateOfBirth = LocalDate.parse(Emp_birth_date_String);
    Period period = Period.between(dateOfBirth, today);
    Emp_Age = period.getYears(); 
    }

    public String getEmp_address() {
        return Emp_address;
    }

    public double getSalary() {
        return salary;
    }

    public String getF_name() {
        return F_name;
    }

    public String getL_name() {
        return L_name;
    }

    public String getEmp_email() {
        return Emp_email;
    }

    public int getEmp_phone() {
        return Emp_phone;
    }

    public String getEmp_sex() {
        return Emp_sex;
    }

}
