package model;
public class advertisers {
private int Emp_ID;
    public advertisers(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

    public int getEmp_ID() {
        return Emp_ID;
    }

    public void setEmp_ID(int Emp_ID) {
        this.Emp_ID = Emp_ID;
    }

}
